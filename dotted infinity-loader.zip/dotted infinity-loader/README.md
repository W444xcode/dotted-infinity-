# Infinity loader

A Pen created on CodePen.io. Original URL: [https://codepen.io/mortezasharifinia/pen/KKZyZdN](https://codepen.io/mortezasharifinia/pen/KKZyZdN).

